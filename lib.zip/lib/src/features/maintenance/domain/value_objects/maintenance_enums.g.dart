// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'maintenance_enums.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

const _$MaintenanceStatusEnumMap = {
  MaintenanceStatus.planned: 'PLANNED',
  MaintenanceStatus.open: 'OPEN',
  MaintenanceStatus.closed: 'CLOSED',
};

const _$MaintenanceTypeEnumMap = {
  MaintenanceType.preventive: 'PREVENTIVE',
  MaintenanceType.corrective: 'CORRECTIVE',
};
